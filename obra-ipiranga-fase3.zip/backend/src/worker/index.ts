import { logger } from '../core/utils/logger';
import './jobs/alertasJob';

logger.info('🚀 Worker BullMQ iniciado e aguardando jobs...');

process.on('SIGTERM', async () => {
  logger.info('Encerrando Worker graciosamente (SIGTERM)...');
  process.exit(0);
});
