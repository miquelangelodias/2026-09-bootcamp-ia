import { Queue } from 'bullmq';
import { redisConnection } from '../../core/config/redis';

export const alertasQueueName = 'alertas-queue';

export const alertasQueue = new Queue(alertasQueueName, {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: 'exponential', delay: 2000 },
  },
});
