import { Worker, Job } from 'bullmq';
import { redisConnection } from '../../core/config/redis';
import { prisma } from '../../core/config/prisma';
import { logger } from '../../core/utils/logger';
import { alertasQueueName } from '../queues/alertasQueue';
import axios from 'axios';

interface AlertaJobData {
  tipo: string;
  origem: string;
  referencia_tabela: string;
  referencia_id: string;
  mensagem: string;
}

export const alertasWorker = new Worker(
  alertasQueueName,
  async (job: Job<AlertaJobData>) => {
    const { tipo, origem, referencia_tabela, referencia_id, mensagem } = job.data;
    logger.info(`Processando alerta [Job ${job.id}]: ${mensagem}`);

    try {
      // 1. Salva na tabela Alertas
      const alerta = await prisma.alertas.create({
        data: { tipo, origem, referencia_tabela, referencia_id, mensagem },
      });

      // 2. Dispara webhook do n8n para WhatsApp
      const n8nUrl = process.env.N8N_WEBHOOK_WHATSAPP_URL;
      if (n8nUrl) {
        await axios.post(n8nUrl, {
          alertaId: alerta.id,
          mensagem: alerta.mensagem,
          tipo: alerta.tipo,
          data: alerta.enviado_em
        });
        logger.info(`Webhook WhatsApp disparado com sucesso para ${n8nUrl}`);
      } else {
        logger.warn('N8N_WEBHOOK_WHATSAPP_URL não está configurada no .env.');
      }

      return alerta;
    } catch (error) {
      logger.error(`Erro ao processar alerta [Job ${job.id}]:`, error);
      throw error;
    }
  },
  { connection: redisConnection }
);

alertasWorker.on('completed', (job) => logger.info(`Job ${job.id} concluído com sucesso.`));
alertasWorker.on('failed', (job, err) => logger.error(`Job ${job?.id} falhou: ${err.message}`));
