import Redis from 'ioredis';
import { logger } from '../utils/logger';

const redisOptions = {
  host: process.env.REDIS_HOST || 'redis',
  port: parseInt(process.env.REDIS_PORT || '6379', 10),
  password: process.env.REDIS_PASSWORD || undefined,
  maxRetriesPerRequest: null,
};

export const redisConnection = new Redis(redisOptions);

redisConnection.on('error', (err) => logger.error('Redis Error:', err));
redisConnection.on('connect', () => logger.info('✅ Conectado ao Redis'));
